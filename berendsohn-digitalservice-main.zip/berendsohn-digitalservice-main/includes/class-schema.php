<?php
namespace BDS;

if ( ! defined( 'ABSPATH' ) ) exit;

class Schema {
    // Basis-Optionen
    const OPT_ENABLED        = 'bds_schema_enabled';
    const OPT_FORCE          = 'bds_schema_force';           // auch ausgeben, wenn SEO-Plugin aktiv
    const OPT_ORG_NAME       = 'bds_schema_org_name';
    const OPT_ORG_LOGO_ID    = 'bds_schema_org_logo_id';
    const OPT_ORG_SAMEAS     = 'bds_schema_org_sameas';      // Zeilen- oder komma-getrennt

    // Tag-Modus (Jobs & Termine)
    const OPT_JOB_ENABLE     = 'bds_schema_job_enable';
    const OPT_EVENT_ENABLE   = 'bds_schema_event_enable';
    const OPT_JOB_TAG        = 'bds_schema_job_tag';         // z. B. "job"
    const OPT_EVENT_TAG      = 'bds_schema_event_tag';       // z. B. "termin"

    // WooCommerce Product (optional)
    const OPT_PRODUCT_ENABLE = 'bds_schema_product_enable';  // standardmäßig AUS

    // Global: Standort / LocalBusiness
    const OPT_LB_ENABLE       = 'bds_lb_enable';
    const OPT_LB_TYPE         = 'bds_lb_type';          // z. B. "LocalBusiness", "Store", "Restaurant" ...
    const OPT_LB_NAME         = 'bds_lb_name';
    const OPT_LB_STREET       = 'bds_lb_street';
    const OPT_LB_PC           = 'bds_lb_pc';
    const OPT_LB_CITY         = 'bds_lb_city';
    const OPT_LB_REGION       = 'bds_lb_region';
    const OPT_LB_COUNTRY      = 'bds_lb_country';
    const OPT_LB_PHONE        = 'bds_lb_phone';
    const OPT_LB_EMAIL        = 'bds_lb_email';
    const OPT_LB_URL          = 'bds_lb_url';
    const OPT_LB_GEO_LAT      = 'bds_lb_geo_lat';
    const OPT_LB_GEO_LNG      = 'bds_lb_geo_lng';
    const OPT_LB_PRICERANGE   = 'bds_lb_price_range';
    const OPT_LB_AREA_SERVED  = 'bds_lb_area_served';
    const OPT_LB_OPENING      = 'bds_lb_opening';       // JSON der Öffnungszeiten

    // Unterstützte Screens für Metaboxen
    protected static array $meta_screens = ['post','page'];

    public static function init() {
        // Settings UI
        add_action('admin_menu',  [ __CLASS__, 'add_settings_page' ]);
        add_action('admin_init',  [ __CLASS__, 'register_settings' ]);
        add_action('admin_enqueue_scripts', [ __CLASS__, 'enqueue_media' ]);

        // Metaboxen
        if ( is_admin() ) {
            add_action('add_meta_boxes', [ __CLASS__, 'register_meta_boxes' ], 10, 2);
            add_action('save_post',      [ __CLASS__, 'save_meta_boxes' ]);
        }

        // JSON-LD Ausgaben
        add_action('wp_head', [ __CLASS__, 'print_jsonld' ], 20);
    }

    /* ---------------- Settings ---------------- */

    public static function add_settings_page() {
        add_options_page(
            __('BDS Schema', 'berendsohn-digitalservice'),
            __('BDS Schema', 'berendsohn-digitalservice'),
            'manage_options',
            'bds-schema',
            [ __CLASS__, 'render_settings_page' ]
        );
    }

    public static function register_settings() {
        // Basis
        register_setting('bds_schema', self::OPT_ENABLED,     ['type'=>'boolean','sanitize_callback'=>[__CLASS__,'sanitize_checkbox'],'default'=>0]);
        register_setting('bds_schema', self::OPT_FORCE,       ['type'=>'boolean','sanitize_callback'=>[__CLASS__,'sanitize_checkbox'],'default'=>0]);
        register_setting('bds_schema', self::OPT_ORG_NAME,    ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_ORG_LOGO_ID, ['type'=>'integer','sanitize_callback'=>'absint','default'=>0]);
        register_setting('bds_schema', self::OPT_ORG_SAMEAS,  ['type'=>'string','sanitize_callback'=>[__CLASS__,'sanitize_sameas'],'default'=>'']);

        // Jobs/Termine per Tag
        register_setting('bds_schema', self::OPT_JOB_ENABLE,   ['type'=>'boolean','sanitize_callback'=>[__CLASS__,'sanitize_checkbox'],'default'=>0]);
        register_setting('bds_schema', self::OPT_EVENT_ENABLE, ['type'=>'boolean','sanitize_callback'=>[__CLASS__,'sanitize_checkbox'],'default'=>0]);
        register_setting('bds_schema', self::OPT_JOB_TAG,      ['type'=>'string','sanitize_callback'=>'sanitize_title','default'=>'job']);
        register_setting('bds_schema', self::OPT_EVENT_TAG,    ['type'=>'string','sanitize_callback'=>'sanitize_title','default'=>'termin']);

        // WooCommerce Product (kontrollierbar, default AUS)
        register_setting('bds_schema', self::OPT_PRODUCT_ENABLE, ['type'=>'boolean','sanitize_callback'=>[__CLASS__,'sanitize_checkbox'],'default'=>0]);

        // Standort / LocalBusiness
        register_setting('bds_schema', self::OPT_LB_ENABLE,      ['type'=>'boolean','sanitize_callback'=>[__CLASS__,'sanitize_checkbox'],'default'=>0]);
        register_setting('bds_schema', self::OPT_LB_TYPE,        ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'LocalBusiness']);
        register_setting('bds_schema', self::OPT_LB_NAME,        ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_STREET,      ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_PC,          ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_CITY,        ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_REGION,      ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_COUNTRY,     ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'DE']);
        register_setting('bds_schema', self::OPT_LB_PHONE,       ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_EMAIL,       ['type'=>'string','sanitize_callback'=>'sanitize_email','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_URL,         ['type'=>'string','sanitize_callback'=>'esc_url_raw','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_GEO_LAT,     ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_GEO_LNG,     ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_PRICERANGE,  ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_AREA_SERVED, ['type'=>'string','sanitize_callback'=>'sanitize_text_field','default'=>'']);
        register_setting('bds_schema', self::OPT_LB_OPENING,     ['type'=>'string','sanitize_callback'=>[__CLASS__,'sanitize_opening_hours'],'default'=>'']);
    }

    public static function enqueue_media($hook) {
        if ($hook === 'settings_page_bds-schema') {
            wp_enqueue_media();
        }
    }

    public static function render_settings_page() {
        if ( ! current_user_can('manage_options') ) return;

        $opening = self::opening_hours_get_option();
        $days = self::weekday_labels();
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('BDS Schema', 'berendsohn-digitalservice'); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields('bds_schema'); ?>

                <h2 class="title"><?php esc_html_e('Allgemein', 'berendsohn-digitalservice'); ?></h2>
                <table class="form-table">
                    <tr><th><?php esc_html_e('Schema aktivieren','berendsohn-digitalservice'); ?></th>
                        <td><label><input type="checkbox" name="<?php echo esc_attr(self::OPT_ENABLED); ?>" value="1" <?php checked(get_option(self::OPT_ENABLED),1); ?>> <?php esc_html_e('JSON-LD-Ausgabe einschalten.','berendsohn-digitalservice'); ?></label></td></tr>
                    <tr><th><?php esc_html_e('Ausgabe erzwingen','berendsohn-digitalservice'); ?></th>
                        <td><label><input type="checkbox" name="<?php echo esc_attr(self::OPT_FORCE); ?>" value="1" <?php checked(get_option(self::OPT_FORCE),1); ?>> <?php esc_html_e('Yoast/Rank Math übergehen (kann Duplikate erzeugen).','berendsohn-digitalservice'); ?></label></td></tr>
                    <tr><th><?php esc_html_e('Name der Organisation','berendsohn-digitalservice'); ?></th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_ORG_NAME); ?>" value="<?php echo esc_attr(get_option(self::OPT_ORG_NAME, get_bloginfo('name'))); ?>"></td></tr>
                    <tr><th><?php esc_html_e('Profile (sameAs)','berendsohn-digitalservice'); ?></th>
                        <td><textarea class="large-text code" rows="3" name="<?php echo esc_attr(self::OPT_ORG_SAMEAS); ?>" placeholder="https://www.facebook.com/yourbrand&#10;https://www.instagram.com/yourbrand"><?php echo esc_textarea(get_option(self::OPT_ORG_SAMEAS,'')); ?></textarea></td></tr>
                </table>

                <h2 class="title"><?php esc_html_e('Jobs & Termine (Tag-Modus)', 'berendsohn-digitalservice'); ?></h2>
                <table class="form-table">
                    <tr><th><?php esc_html_e('JobPosting ausgeben','berendsohn-digitalservice'); ?></th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPT_JOB_ENABLE); ?>" value="1" <?php checked(get_option(self::OPT_JOB_ENABLE),1); ?>> <?php esc_html_e('Auf Einzelseiten mit Tag','berendsohn-digitalservice'); ?></label>
                            &nbsp; Tag: <input type="text" name="<?php echo esc_attr(self::OPT_JOB_TAG); ?>" value="<?php echo esc_attr(get_option(self::OPT_JOB_TAG,'job')); ?>">
                        </td></tr>
                    <tr><th><?php esc_html_e('Event ausgeben','berendsohn-digitalservice'); ?></th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPT_EVENT_ENABLE); ?>" value="1" <?php checked(get_option(self::OPT_EVENT_ENABLE),1); ?>> <?php esc_html_e('Auf Einzelseiten mit Tag','berendsohn-digitalservice'); ?></label>
                            &nbsp; Tag: <input type="text" name="<?php echo esc_attr(self::OPT_EVENT_TAG); ?>" value="<?php echo esc_attr(get_option(self::OPT_EVENT_TAG,'termin')); ?>">
                        </td></tr>
                </table>

                <h2 class="title"><?php esc_html_e('WooCommerce Produkt', 'berendsohn-digitalservice'); ?></h2>
                <table class="form-table">
                    <tr><th><?php esc_html_e('Product-Schema für WooCommerce aktivieren', 'berendsohn-digitalservice'); ?></th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPT_PRODUCT_ENABLE); ?>" value="1" <?php checked(get_option(self::OPT_PRODUCT_ENABLE),1); ?>> <?php esc_html_e('Auf Einzel-Produktseiten ein Product-Schema ausgeben (nur wenn kein SEO-Plugin aktiv ist oder „erzwingen“ aktiv).', 'berendsohn-digitalservice'); ?></label>
                            <p class="description"><?php esc_html_e('Empfehlung: AUS lassen, wenn WooCommerce/Yoast bereits Schema ausgibt (um Duplikate zu vermeiden).', 'berendsohn-digitalservice'); ?></p>
                        </td>
                    </tr>
                </table>

                <h2 class="title"><?php esc_html_e('Standort / LocalBusiness', 'berendsohn-digitalservice'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th><?php esc_html_e('LocalBusiness-Schema aktivieren', 'berendsohn-digitalservice'); ?></th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPT_LB_ENABLE); ?>" value="1" <?php checked( get_option(self::OPT_LB_ENABLE,0), 1 ); ?> />
                                <?php esc_html_e('Standortdaten + Öffnungszeiten als LocalBusiness ausgeben.', 'berendsohn-digitalservice'); ?></label>
                        </td>
                    </tr>
                    <tr><th><?php esc_html_e('Untertyp','berendsohn-digitalservice'); ?></th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_TYPE); ?>" value="<?php echo esc_attr(get_option(self::OPT_LB_TYPE,'LocalBusiness')); ?>">
                        <p class="description"><?php esc_html_e('Beispiel: LocalBusiness, Store, Restaurant, ProfessionalService …','berendsohn-digitalservice'); ?></p></td>
                    </tr>
                    <tr><th><?php esc_html_e('Anzeigename (optional)','berendsohn-digitalservice'); ?></th>
                        <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_NAME); ?>" value="<?php echo esc_attr(get_option(self::OPT_LB_NAME,'')); ?>"></td></tr>
                    <tr><th><?php esc_html_e('Adresse','berendsohn-digitalservice'); ?></th>
                        <td>
                            <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_STREET); ?>" placeholder="<?php esc_attr_e('Straße Hausnr.','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr(get_option(self::OPT_LB_STREET,'')); ?>">,
                            <input type="text" style="width:80px" name="<?php echo esc_attr(self::OPT_LB_PC); ?>" placeholder="PLZ" value="<?php echo esc_attr(get_option(self::OPT_LB_PC,'')); ?>">
                            <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_CITY); ?>" placeholder="<?php esc_attr_e('Ort','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr(get_option(self::OPT_LB_CITY,'')); ?>"><br>
                            <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_REGION); ?>" placeholder="<?php esc_attr_e('Bundesland/Region','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr(get_option(self::OPT_LB_REGION,'')); ?>">
                            <input type="text" style="width:100px" name="<?php echo esc_attr(self::OPT_LB_COUNTRY); ?>" placeholder="DE" value="<?php echo esc_attr(get_option(self::OPT_LB_COUNTRY,'DE')); ?>">
                        </td>
                    </tr>
                    <tr><th><?php esc_html_e('Kontakt','berendsohn-digitalservice'); ?></th>
                        <td>
                            <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_PHONE); ?>" placeholder="<?php esc_attr_e('Telefon','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr(get_option(self::OPT_LB_PHONE,'')); ?>">
                            <input type="email" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_EMAIL); ?>" placeholder="info@example.com" value="<?php echo esc_attr(get_option(self::OPT_LB_EMAIL,'')); ?>">
                            <input type="url" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_URL); ?>" placeholder="https://example.com" value="<?php echo esc_attr(get_option(self::OPT_LB_URL,'')); ?>">
                        </td>
                    </tr>
                    <tr><th><?php esc_html_e('Koordinaten (optional)','berendsohn-digitalservice'); ?></th>
                        <td>
                            <input type="text" style="width:120px" name="<?php echo esc_attr(self::OPT_LB_GEO_LAT); ?>" placeholder="Breite (lat)" value="<?php echo esc_attr(get_option(self::OPT_LB_GEO_LAT,'')); ?>">
                            <input type="text" style="width:120px" name="<?php echo esc_attr(self::OPT_LB_GEO_LNG); ?>" placeholder="Länge (lng)" value="<?php echo esc_attr(get_option(self::OPT_LB_GEO_LNG,'')); ?>">
                        </td>
                    </tr>
                    <tr><th><?php esc_html_e('Preisbereich / Gebiet (optional)','berendsohn-digitalservice'); ?></th>
                        <td>
                            <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_PRICERANGE); ?>" placeholder="€€" value="<?php echo esc_attr(get_option(self::OPT_LB_PRICERANGE,'')); ?>">
                            <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPT_LB_AREA_SERVED); ?>" placeholder="<?php esc_attr_e('Versorgte Regionen (Freitext)','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr(get_option(self::OPT_LB_AREA_SERVED,'')); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Öffnungszeiten','berendsohn-digitalservice'); ?></th>
                        <td>
                            <style>
                                .bds-oh-grid{display:grid;grid-template-columns:110px 1fr 1fr;gap:6px;align-items:center;max-width:780px}
                                .bds-oh-grid .day{font-weight:600}
                                .bds-oh-range{display:flex;gap:6px}
                                .bds-oh-range input{width:130px}
                                .bds-oh-note{color:#555}
                            </style>
                            <div class="bds-oh-grid">
                                <div></div><div class="bds-oh-note"><?php esc_html_e('Zeitspanne 1','berendsohn-digitalservice'); ?></div><div class="bds-oh-note"><?php esc_html_e('Zeitspanne 2 (optional)','berendsohn-digitalservice'); ?></div>
                                <?php foreach($days as $key=>$label):
                                    $r1o = esc_attr($opening[$key][0]['opens']  ?? '');
                                    $r1c = esc_attr($opening[$key][0]['closes'] ?? '');
                                    $r2o = esc_attr($opening[$key][1]['opens']  ?? '');
                                    $r2c = esc_attr($opening[$key][1]['closes'] ?? '');
                                ?>
                                <div class="day"><?php echo esc_html($label); ?></div>
                                <div class="bds-oh-range">
                                    <input type="time" name="<?php echo esc_attr(self::OPT_LB_OPENING); ?>[<?php echo esc_attr($key); ?>][0][opens]"  value="<?php echo $r1o; ?>">
                                    <span>–</span>
                                    <input type="time" name="<?php echo esc_attr(self::OPT_LB_OPENING); ?>[<?php echo esc_attr($key); ?>][0][closes]" value="<?php echo $r1c; ?>">
                                </div>
                                <div class="bds-oh-range">
                                    <input type="time" name="<?php echo esc_attr(self::OPT_LB_OPENING); ?>[<?php echo esc_attr($key); ?>][1][opens]"  value="<?php echo $r2o; ?>">
                                    <span>–</span>
                                    <input type="time" name="<?php echo esc_attr(self::OPT_LB_OPENING); ?>[<?php echo esc_attr($key); ?>][1][closes]" value="<?php echo $r2c; ?>">
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <p class="description"><?php esc_html_e('Felder leer lassen = geschlossen. Zeiten im Format HH:MM (24h).','berendsohn-digitalservice'); ?></p>
                        </td>
                    </tr>
                </table>

                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public static function sanitize_checkbox($v) { return !empty($v) ? 1 : 0; }

    public static function sanitize_sameas($v) {
        $v = is_string($v) ? $v : '';
        $lines = preg_split('/[\r\n,]+/', $v);
        $urls = array_filter(array_map('trim', $lines));
        $urls = array_values(array_filter($urls, function($u){ return filter_var($u, FILTER_VALIDATE_URL); }));
        return implode("\n", $urls);
    }

    // Öffnungszeiten: POST-Array -> JSON speichern
    public static function sanitize_opening_hours($v) {
        if (is_string($v)) return $v; // bereits JSON (Edge-Fall)
        if (!is_array($v)) return '';
        $clean = [];
        foreach (self::weekday_labels() as $key => $label) {
            $ranges = $v[$key] ?? [];
            $out = [];
            foreach ([0,1] as $i) {
                $opens  = isset($ranges[$i]['opens'])  ? trim($ranges[$i]['opens'])  : '';
                $closes = isset($ranges[$i]['closes']) ? trim($ranges[$i]['closes']) : '';
                if ($opens !== '' && $closes !== '') {
                    if ( preg_match('/^\d{2}:\d{2}$/', $opens) && preg_match('/^\d{2}:\d{2}$/', $closes) ) {
                        $out[] = ['opens'=>$opens,'closes'=>$closes];
                    }
                }
            }
            if ($out) $clean[$key] = $out;
        }
        return $clean ? wp_json_encode($clean, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) : '';
    }

    /* ---------------- Meta-Boxen ---------------- */

 public static function register_meta_boxes($post_type, $post) {
    // Nur auf unseren Screens arbeiten
    if ( ! in_array( $post_type, self::$meta_screens, true ) ) return;

    // --- JobPosting-Box nur anzeigen, wenn Option aktiv UND Tag vorhanden ---
    if ( get_option(self::OPT_JOB_ENABLE, 0) ) {
        $job_tag = get_option(self::OPT_JOB_TAG, 'job');
        if ( $job_tag && has_term( $job_tag, 'post_tag', $post ) ) {
            add_meta_box(
                'bds_job_box',
                __('Job-Daten (Schema.org JobPosting)', 'berendsohn-digitalservice'),
                [ __CLASS__, 'render_job_box' ],
                $post_type,
                'normal',
                'default'
            );
        }
    }

    // --- Event-Box nur anzeigen, wenn Option aktiv UND Tag vorhanden ---
    if ( get_option(self::OPT_EVENT_ENABLE, 0) ) {
        $event_tag = get_option(self::OPT_EVENT_TAG, 'termin');
        if ( $event_tag && has_term( $event_tag, 'post_tag', $post ) ) {
            add_meta_box(
                'bds_event_box',
                __('Termin-Daten (Schema.org Event)', 'berendsohn-digitalservice'),
                [ __CLASS__, 'render_event_box' ],
                $post_type,
                'normal',
                'default'
            );
        }
    }
}

    protected static function show_job_box_for_post(int $post_id): bool {
        if ( get_post_status($post_id) === 'auto-draft' ) return true; // beim Anlegen sichtbar
        $tag = get_option(self::OPT_JOB_TAG,'job');
        return $tag && has_term($tag, 'post_tag', $post_id);
    }

    protected static function show_event_box_for_post(int $post_id): bool {
        if ( get_post_status($post_id) === 'auto-draft' ) return true;
        $tag = get_option(self::OPT_EVENT_TAG,'termin');
        return $tag && has_term($tag, 'post_tag', $post_id);
    }

    public static function render_job_box(\WP_Post $post) {
        wp_nonce_field('bds_job_box_save','bds_job_box_nonce');

        $get = fn($k,$d='') => get_post_meta($post->ID,$k,true) ?: $d;

        $title   = $get('bds_job_title');
        $desc    = $get('bds_job_description');
        $posted  = $get('bds_job_date_posted');     // "Y-m-d H:i:s"
        $valid   = $get('bds_job_valid_through');   // "Y-m-d H:i:s"
        $types   = $get('bds_job_employment_type'); // CSV
        $locn    = $get('bds_job_location_name');
        $street  = $get('bds_job_street');
        $pc      = $get('bds_job_pc');
        $city    = $get('bds_job_city');
        $region  = $get('bds_job_region');
        $country = $get('bds_job_country','DE');
        $sal     = $get('bds_job_salary_value');
        $cur     = $get('bds_job_salary_currency','EUR');
        $unit    = $get('bds_job_salary_unit');     // MONTH|YEAR|HOUR
        $ident   = $get('bds_job_identifier');
        $direct  = (bool) $get('bds_job_direct_apply', 0);
        $locType = strtoupper( (string) $get('bds_job_job_location_type') ); // ON_SITE|HYBRID|REMOTE
        $areas   = $get('bds_job_applicant_location'); // CSV

        $to_local_input = function($v){
            if (!$v) return '';
            $dt = date_create($v, wp_timezone());
            return $dt ? $dt->format('Y-m-d\TH:i') : '';
        };
        ?>
        <style>.bds-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.bds-grid .full{grid-column:1/-1}</style>
        <div class="bds-grid">
            <label class="full"><strong><?php esc_html_e('Anzeigen-Titel (optional)', 'berendsohn-digitalservice'); ?></strong>
                <input type="text" class="widefat" name="bds_job_title" value="<?php echo esc_attr($title); ?>"></label>

            <label class="full"><strong><?php esc_html_e('Kurzbeschreibung (optional)', 'berendsohn-digitalservice'); ?></strong>
                <textarea class="widefat" rows="3" name="bds_job_description"><?php echo esc_textarea($desc); ?></textarea></label>

            <label><strong><?php esc_html_e('Datum veröffentlicht', 'berendsohn-digitalservice'); ?></strong>
                <input type="datetime-local" name="bds_job_date_posted_local" value="<?php echo esc_attr($to_local_input($posted)); ?>"></label>

            <label><strong><?php esc_html_e('Gültig bis', 'berendsohn-digitalservice'); ?></strong>
                <input type="datetime-local" name="bds_job_valid_through_local" value="<?php echo esc_attr($to_local_input($valid)); ?>"></label>

            <label class="full"><strong><?php esc_html_e('Beschäftigungsart (CSV)', 'berendsohn-digitalservice'); ?></strong>
                <input type="text" class="widefat" name="bds_job_employment_type" placeholder="FULL_TIME,PART_TIME" value="<?php echo esc_attr($types); ?>"></label>

            <div class="full"><strong><?php esc_html_e('Arbeitsort', 'berendsohn-digitalservice'); ?></strong></div>
            <label class="full"><input type="text" class="widefat" name="bds_job_location_name" placeholder="<?php esc_attr_e('Standortname / Niederlassung','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr($locn); ?>"></label>
            <label><input type="text" class="widefat" name="bds_job_street" placeholder="<?php esc_attr_e('Straße Hausnr.','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr($street); ?>"></label>
            <label><input type="text" name="bds_job_pc" placeholder="PLZ" value="<?php echo esc_attr($pc); ?>"></label>
            <label><input type="text" name="bds_job_city" placeholder="<?php esc_attr_e('Ort','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr($city); ?>"></label>
            <label><input type="text" name="bds_job_region" placeholder="<?php esc_attr_e('Bundesland/Region','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr($region); ?>"></label>
            <label><input type="text" name="bds_job_country" placeholder="DE" value="<?php echo esc_attr($country); ?>"></label>

            <div class="full"><strong><?php esc_html_e('Vergütung (optional)', 'berendsohn-digitalservice'); ?></strong></div>
            <label><input type="number" step="0.01" min="0" name="bds_job_salary_value" placeholder="3500" value="<?php echo esc_attr($sal); ?>"></label>
            <label><input type="text" name="bds_job_salary_currency" placeholder="EUR" value="<?php echo esc_attr($cur); ?>"></label>
            <label><input type="text" name="bds_job_salary_unit" placeholder="MONTH|YEAR|HOUR" value="<?php echo esc_attr($unit); ?>"></label>

            <label><strong><?php esc_html_e('Interne Kennung (optional)', 'berendsohn-digitalservice'); ?></strong>
                <input type="text" class="widefat" name="bds_job_identifier" value="<?php echo esc_attr($ident); ?>"></label>

            <label><strong><?php esc_html_e('Bewerbung direkt möglich', 'berendsohn-digitalservice'); ?></strong><br>
                <label><input type="checkbox" name="bds_job_direct_apply" value="1" <?php checked($direct,true); ?>> <?php esc_html_e('Direct Apply', 'berendsohn-digitalservice'); ?></label>
            </label>

            <label><strong><?php esc_html_e('Arbeitsmodell', 'berendsohn-digitalservice'); ?></strong>
                <select name="bds_job_job_location_type">
                    <?php $opts=[''=>'—','ON_SITE'=>'On-Site','HYBRID'=>'Hybrid','REMOTE'=>'Remote'];
                    foreach($opts as $k=>$lbl){ echo '<option value="'.esc_attr($k).'" '.selected($locType,$k,false).'>'.esc_html($lbl).'</option>'; } ?>
                </select>
            </label>

            <label class="full"><strong><?php esc_html_e('Bewerber-Regionen (CSV, optional)', 'berendsohn-digitalservice'); ?></strong>
                <input type="text" class="widefat" name="bds_job_applicant_location" placeholder="DE, AT, CH" value="<?php echo esc_attr($areas); ?>"></label>
        </div>
        <?php
    }

    public static function render_event_box(\WP_Post $post) {
        wp_nonce_field('bds_event_box_save','bds_event_box_nonce');

        $get = fn($k,$d='') => get_post_meta($post->ID,$k,true) ?: $d;

        $name   = $get('bds_event_name');
        $desc   = $get('bds_event_description');
        $start  = $get('bds_event_start');      // "Y-m-d H:i:s"
        $end    = $get('bds_event_end');
        $door   = $get('bds_event_door_time');
        $status = $get('bds_event_status','https://schema.org/EventScheduled');
        $mode   = $get('bds_event_attendance_mode','https://schema.org/OfflineEventAttendanceMode');
        $locn   = $get('bds_event_location_name');
        $street = $get('bds_event_street');
        $pc     = $get('bds_event_pc');
        $city   = $get('bds_event_city');
        $region = $get('bds_event_region');
        $country= $get('bds_event_country','DE');
        $price  = $get('bds_event_price');
        $curr   = $get('bds_event_currency','EUR');
        $ticket = $get('bds_event_url');
        $stream = $get('bds_event_stream_url');
        $isfree = (bool) $get('bds_event_is_free', 0);
        $capmax = $get('bds_event_capacity_max');
        $caprem = $get('bds_event_capacity_left');

        $to_local_input = function($v){
            if (!$v) return '';
            $dt = date_create($v, wp_timezone());
            return $dt ? $dt->format('Y-m-d\TH:i') : '';
        };
        ?>
        <style>.bds-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.bds-grid .full{grid-column:1/-1}</style>
        <div class="bds-grid">
            <label class="full"><strong><?php esc_html_e('Event-Name (optional)', 'berendsohn-digitalservice'); ?></strong>
                <input type="text" class="widefat" name="bds_event_name" value="<?php echo esc_attr($name); ?>"></label>

            <label class="full"><strong><?php esc_html_e('Kurzbeschreibung (optional)', 'berendsohn-digitalservice'); ?></strong>
                <textarea class="widefat" rows="3" name="bds_event_description"><?php echo esc_textarea($desc); ?></textarea></label>

            <label><strong><?php esc_html_e('Beginn', 'berendsohn-digitalservice'); ?></strong>
                <input type="datetime-local" name="bds_event_start_local" value="<?php echo esc_attr($to_local_input($start)); ?>"></label>

            <label><strong><?php esc_html_e('Ende (optional)', 'berendsohn-digitalservice'); ?></strong>
                <input type="datetime-local" name="bds_event_end_local" value="<?php echo esc_attr($to_local_input($end)); ?>"></label>

            <label><strong><?php esc_html_e('Einlass (optional)', 'berendsohn-digitalservice'); ?></strong>
                <input type="datetime-local" name="bds_event_door_time_local" value="<?php echo esc_attr($to_local_input($door)); ?>"></label>

            <label><strong><?php esc_html_e('Status', 'berendsohn-digitalservice'); ?></strong>
                <select name="bds_event_status">
                    <?php
                    $statuses = [
                        'https://schema.org/EventScheduled' => 'Geplant',
                        'https://schema.org/EventPostponed' => 'Verschoben',
                        'https://schema.org/EventCancelled' => 'Abgesagt',
                        'https://schema.org/EventRescheduled'=> 'Neu terminiert',
                    ];
                    foreach($statuses as $val=>$lbl){ echo '<option value="'.esc_attr($val).'" '.selected($status,$val,false).'>'.esc_html($lbl).'</option>'; }
                    ?>
                </select>
            </label>

            <label><strong><?php esc_html_e('Teilnahme', 'berendsohn-digitalservice'); ?></strong>
                <select name="bds_event_attendance_mode">
                    <?php
                    $modes = [
                        'https://schema.org/OfflineEventAttendanceMode' => 'Vor Ort',
                        'https://schema.org/OnlineEventAttendanceMode'  => 'Online',
                        'https://schema.org/MixedEventAttendanceMode'   => 'Hybrid',
                    ];
                    foreach($modes as $val=>$lbl){ echo '<option value="'.esc_attr($val).'" '.selected($mode,$val,false).'>'.esc_html($lbl).'</option>'; }
                    ?>
                </select>
            </label>

            <div class="full"><strong><?php esc_html_e('Ort', 'berendsohn-digitalservice'); ?></strong></div>
            <label class="full"><input type="text" class="widefat" name="bds_event_location_name" placeholder="<?php esc_attr_e('Veranstaltungsort','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr($locn); ?>"></label>
            <label><input type="text" class="widefat" name="bds_event_street" placeholder="<?php esc_attr_e('Straße Hausnr.','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr($street); ?>"></label>
            <label><input type="text" name="bds_event_pc" placeholder="PLZ" value="<?php echo esc_attr($pc); ?>"></label>
            <label><input type="text" name="bds_event_city" placeholder="<?php esc_attr_e('Ort','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr($city); ?>"></label>
            <label><input type="text" name="bds_event_region" placeholder="<?php esc_attr_e('Bundesland/Region','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr($region); ?>"></label>
            <label><input type="text" name="bds_event_country" placeholder="DE" value="<?php echo esc_attr($country); ?>"></label>

            <div class="full"><strong><?php esc_html_e('Tickets & Preis (optional)', 'berendsohn-digitalservice'); ?></strong></div>
            <label><input type="number" step="0.01" min="0" name="bds_event_price" placeholder="0.00" value="<?php echo esc_attr($price); ?>"></label>
            <label><input type="text" name="bds_event_currency" placeholder="EUR" value="<?php echo esc_attr($curr); ?>"></label>
            <label class="full"><input type="url" class="widefat" name="bds_event_url" placeholder="<?php esc_attr_e('Ticket-/Event-URL','berendsohn-digitalservice'); ?>" value="<?php echo esc_attr($ticket); ?>"></label>

            <label class="full"><strong><?php esc_html_e('Stream-URL (bei Online)', 'berendsohn-digitalservice'); ?></strong>
                <input type="url" class="widefat" name="bds_event_stream_url" value="<?php echo esc_attr($stream); ?>"></label>

            <label><strong><?php esc_html_e('Kostenlos', 'berendsohn-digitalservice'); ?></strong><br>
                <label><input type="checkbox" name="bds_event_is_free" value="1" <?php checked($isfree,true); ?>> <?php esc_html_e('Event ist kostenlos', 'berendsohn-digitalservice'); ?></label>
            </label>

            <label><strong><?php esc_html_e('Kapazität gesamt (optional)', 'berendsohn-digitalservice'); ?></strong>
                <input type="number" min="0" step="1" name="bds_event_capacity_max" value="<?php echo esc_attr($capmax); ?>"></label>

            <label><strong><?php esc_html_e('Restkapazität (optional)', 'berendsohn-digitalservice'); ?></strong>
                <input type="number" min="0" step="1" name="bds_event_capacity_left" value="<?php echo esc_attr($caprem); ?>"></label>
        </div>
        <?php
    }

    public static function save_meta_boxes($post_id) {
        if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision($post_id) ) return;
        if ( ! current_user_can('edit_post', $post_id) ) return;

        if ( isset($_POST['bds_job_box_nonce']) && wp_verify_nonce($_POST['bds_job_box_nonce'], 'bds_job_box_save') ) {
            self::save_job_meta($post_id, $_POST);
        }
        if ( isset($_POST['bds_event_box_nonce']) && wp_verify_nonce($_POST['bds_event_box_nonce'], 'bds_event_box_save') ) {
            self::save_event_meta($post_id, $_POST);
        }
    }

    protected static function save_job_meta(int $post_id, array $src) {
        $fields_text = [
            'bds_job_title','bds_job_description','bds_job_employment_type','bds_job_location_name',
            'bds_job_street','bds_job_pc','bds_job_city','bds_job_region','bds_job_country',
            'bds_job_salary_currency','bds_job_salary_unit','bds_job_identifier',
            'bds_job_job_location_type','bds_job_applicant_location',
        ];
        foreach($fields_text as $k){
            if ( isset($src[$k]) ) update_post_meta($post_id, $k, sanitize_text_field($src[$k]));
        }

        if ( isset($src['bds_job_salary_value']) ) update_post_meta($post_id, 'bds_job_salary_value', is_numeric($src['bds_job_salary_value']) ? (float)$src['bds_job_salary_value'] : '' );
        update_post_meta($post_id, 'bds_job_direct_apply', !empty($src['bds_job_direct_apply']) ? 1 : 0 );

        $dates = [
            'bds_job_date_posted_local'   => 'bds_job_date_posted',
            'bds_job_valid_through_local' => 'bds_job_valid_through',
        ];
        foreach($dates as $in=>$out){
            if ( isset($src[$in]) ) {
                $val = self::from_input_datetime_local($src[$in]);
                if ($val) update_post_meta($post_id, $out, $val); else delete_post_meta($post_id,$out);
            }
        }
    }

    protected static function save_event_meta(int $post_id, array $src) {
        $fields_text = [
            'bds_event_name','bds_event_description','bds_event_status','bds_event_attendance_mode',
            'bds_event_location_name','bds_event_street','bds_event_pc','bds_event_city','bds_event_region','bds_event_country',
            'bds_event_currency','bds_event_url','bds_event_stream_url',
        ];
        foreach($fields_text as $k){
            if ( isset($src[$k]) ) update_post_meta($post_id, $k, sanitize_text_field($src[$k]));
        }

        if ( isset($src['bds_event_price']) ) update_post_meta($post_id, 'bds_event_price', is_numeric($src['bds_event_price']) ? (float)$src['bds_event_price'] : '' );
        if ( isset($src['bds_event_capacity_max']) ) update_post_meta($post_id, 'bds_event_capacity_max', is_numeric($src['bds_event_capacity_max']) ? (int)$src['bds_event_capacity_max'] : '' );
        if ( isset($src['bds_event_capacity_left']) ) update_post_meta($post_id, 'bds_event_capacity_left', is_numeric($src['bds_event_capacity_left']) ? (int)$src['bds_event_capacity_left'] : '' );

        update_post_meta($post_id, 'bds_event_is_free', !empty($src['bds_event_is_free']) ? 1 : 0 );

        $dates = [
            'bds_event_start_local'     => 'bds_event_start',
            'bds_event_end_local'       => 'bds_event_end',
            'bds_event_door_time_local' => 'bds_event_door_time',
        ];
        foreach($dates as $in=>$out){
            if ( isset($src[$in]) ) {
                $val = self::from_input_datetime_local($src[$in]);
                if ($val) update_post_meta($post_id, $out, $val); else delete_post_meta($post_id,$out);
            }
        }
    }

    /* ---------------- JSON-LD Ausgabe ---------------- */

    protected static function seo_plugin_active(): bool {
        return defined('WPSEO_VERSION') || function_exists('rank_math');
    }

    public static function print_jsonld() {
        if ( ! get_option(self::OPT_ENABLED, 0) ) return;

        $force = (bool) get_option(self::OPT_FORCE, 0);
        $seo_active = self::seo_plugin_active();

        $org_name = get_option(self::OPT_ORG_NAME, get_bloginfo('name'));
        $logo_id  = (int) get_option(self::OPT_ORG_LOGO_ID, 0);
        $logo_url = $logo_id ? wp_get_attachment_url($logo_id) : ( function_exists('get_theme_mod') ? wp_get_attachment_url(get_theme_mod('custom_logo')) : '' );
        $sameAs   = self::get_sameas_array();

        // Organization + WebSite nur ausgeben, wenn kein SEO-Plugin aktiv ist oder "Force"
        if ( $force || ! $seo_active ) {
            echo self::jsonld([
                '@context' => 'https://schema.org',
                '@type'    => 'Organization',
                'name'     => $org_name,
                'url'      => home_url('/'),
                'logo'     => $logo_url ?: null,
                'sameAs'   => !empty($sameAs) ? $sameAs : null,
            ]);
            echo self::jsonld([
                '@context' => 'https://schema.org',
                '@type'    => 'WebSite',
                'url'      => home_url('/'),
                'name'     => get_bloginfo('name'),
                'potentialAction' => [
                    '@type'       => 'SearchAction',
                    'target'      => home_url('/?s={search_term_string}'),
                    'query-input' => 'required name=search_term_string'
                ]
            ]);
        }

        // BlogPosting auf Beiträgen (mit mainEntityOfPage)
        if ( is_singular('post') && ( $force || ! $seo_active ) ) {
            global $post;
            echo self::jsonld([
                '@context' => 'https://schema.org',
                '@type' => 'BlogPosting',
                'mainEntityOfPage' => get_permalink($post),
                'mainEntity'       => get_permalink($post), // optional redundant, schadet nicht
                'headline' => get_the_title($post),
                'image' => get_the_post_thumbnail_url($post, 'full') ?: null,
                'datePublished' => get_the_date('c', $post),
                'dateModified'  => get_the_modified_date('c', $post),
                'author' => [
                    '@type' => 'Person',
                    'name'  => get_the_author_meta('display_name', $post->post_author)
                ],
                'publisher' => [
                    '@type' => 'Organization',
                    'name'  => $org_name,
                    'logo'  => $logo_url ? ['@type'=>'ImageObject','url'=>$logo_url] : null
                ],
                'description' => wp_strip_all_tags( get_the_excerpt($post) )
            ]);
        }

        // WooCommerce Product (nur wenn Option aktiv + (kein SEO-Plugin oder Force))
        if ( function_exists('wc_get_product') && is_singular('product') && get_option(self::OPT_PRODUCT_ENABLE,0) && ( $force || ! $seo_active ) ) {
            $product = wc_get_product(get_the_ID());
            if ( $product ) {
                $data = [
                    '@context'        => 'https://schema.org',
                    '@type'           => 'Product',
                    'mainEntityOfPage'=> get_permalink(),
                    'name'            => get_the_title(),
                    'image'           => wp_get_attachment_image_url($product->get_image_id(), 'full') ?: null,
                    'description'     => wp_strip_all_tags(get_the_excerpt()),
                    'sku'             => $product->get_sku() ?: null,
                    'brand'           => ['@type'=>'Brand','name'=>$org_name],
                    'offers' => [
                        '@type'         => 'Offer',
                        'priceCurrency' => get_woocommerce_currency(),
                        'price'         => $product->get_price(),
                        'availability'  => $product->is_in_stock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
                        'url'           => get_permalink(),
                        'itemCondition' => 'https://schema.org/NewCondition'
                    ],
                ];
                if ($product->get_average_rating() && $product->get_rating_count()) {
                    $data['aggregateRating'] = [
                        '@type'       => 'AggregateRating',
                        'ratingValue' => (string) $product->get_average_rating(),
                        'reviewCount' => (int) $product->get_rating_count(),
                    ];
                }
                echo self::jsonld($data);
            }
        }

        // JobPosting/Event per Tag IMMER ausliefern (auch wenn Yoast aktiv ist)
        if ( self::is_job_tag_context() ) {
            $job = self::build_jobposting_node($org_name, $logo_url ?: null);
            if ( $job ) echo self::jsonld( $job );
        }

        if ( self::is_event_tag_context() ) {
            $event = self::build_event_node($org_name);
            if ( $event ) echo self::jsonld( $event );
        }

        // LocalBusiness immer ausgeben, wenn aktiviert
        if ( get_option(self::OPT_LB_ENABLE,0) ) {
            $lb = self::build_localbusiness_node($org_name, $logo_url ?: null);
            if ( $lb ) echo self::jsonld($lb);
        }

        echo "\n" . "<!-- BDS Schema active: " . esc_html( $seo_active ? ($force?'forced (SEO present)':'seo-present') : 'no-seo' ) . " -->\n";
    }

    protected static function get_sameas_array(): array {
        $raw = (string) get_option(self::OPT_ORG_SAMEAS, '');
        if (!$raw) return [];
        $lines = preg_split('/[\r\n,]+/', $raw);
        $urls  = array_values(array_filter(array_map('trim', $lines)));
        $urls  = array_values(array_filter($urls, fn($u)=>filter_var($u, FILTER_VALIDATE_URL)));
        return $urls;
    }

    /* ------------- Builder ------------- */

    protected static function is_job_tag_context(): bool {
        if ( !is_singular() || ! get_option(self::OPT_JOB_ENABLE,0) ) return false;
        $tag = get_option(self::OPT_JOB_TAG, 'job');
        return $tag && has_term( $tag, 'post_tag', get_the_ID() );
    }

    protected static function is_event_tag_context(): bool {
        if ( !is_singular() || ! get_option(self::OPT_EVENT_ENABLE,0) ) return false;
        $tag = get_option(self::OPT_EVENT_TAG, 'termin');
        return $tag && has_term( $tag, 'post_tag', get_the_ID() );
    }

    protected static function array_remove_nulls(array $a): array {
        foreach ($a as $k=>$v) {
            if (is_array($v)) $a[$k] = self::array_remove_nulls($v);
        }
        return array_filter($a, fn($v)=>$v!==null && $v!==[] && $v!=='');
    }

    // WP-Zeitzone -> ISO-8601
    protected static function to_iso8601(?string $local_datetime): ?string {
        if ( ! $local_datetime ) return null;
        try {
            $tz = wp_timezone();
            $dt = date_create_from_format('Y-m-d H:i:s', $local_datetime, $tz);
            if ( ! $dt ) return null;
            return $dt->format('c');
        } catch (\Throwable $e) {
            return null;
        }
    }

    // aus <input type="datetime-local"> (Y-m-d\TH:i) nach Y-m-d H:i:s
    protected static function from_input_datetime_local(?string $v): ?string {
        $v = is_string($v) ? trim($v) : '';
        if ($v === '') return null;
        $tz = wp_timezone();
        $dt = date_create_from_format('Y-m-d\TH:i', $v, $tz);
        if ( ! $dt ) return null;
        return $dt->format('Y-m-d H:i:s');
    }

    /** JobPosting */
    protected static function build_jobposting_node(string $org_name, ?string $logo_url): ?array {
        $post_id = get_the_ID();

        $title       = get_post_meta($post_id, 'bds_job_title', true ) ?: get_the_title($post_id);
        $desc        = wp_strip_all_tags( get_post_meta($post_id, 'bds_job_description', true ) ?: get_the_excerpt($post_id) );

        $posted_raw  = get_post_meta($post_id, 'bds_job_date_posted', true );
        $valid_raw   = get_post_meta($post_id, 'bds_job_valid_through', true );
        $datePosted   = self::to_iso8601($posted_raw) ?: get_the_date('c', $post_id);
        $validThrough = self::to_iso8601($valid_raw);

        $empTypesCsv = get_post_meta($post_id, 'bds_job_employment_type', true );
        $empTypes    = array_values(array_filter( array_map('trim', explode(',', (string)$empTypesCsv)) ));

        $loc_name = get_post_meta($post_id, 'bds_job_location_name', true );
        $street   = get_post_meta($post_id, 'bds_job_street', true );
        $pc       = get_post_meta($post_id, 'bds_job_pc', true );
        $city     = get_post_meta($post_id, 'bds_job_city', true );
        $region   = get_post_meta($post_id, 'bds_job_region', true );
        $country  = get_post_meta($post_id, 'bds_job_country', true ) ?: 'DE';

        $salary_value    = get_post_meta($post_id, 'bds_job_salary_value', true );
        $salary_currency = get_post_meta($post_id, 'bds_job_salary_currency', true ) ?: 'EUR';
        $salary_unit     = get_post_meta($post_id, 'bds_job_salary_unit', true );

        $job = [
            '@context'         => 'https://schema.org',
            '@type'            => 'JobPosting',
            'title'            => $title,
            'description'      => $desc,
            'mainEntityOfPage' => get_permalink($post_id),
            'datePosted'       => $datePosted,
            'validThrough'     => $validThrough ?: null,
            'hiringOrganization' => [
                '@type' => 'Organization',
                'name'  => $org_name,
                'sameAs'=> home_url('/'),
                'logo'  => $logo_url ?: null,
            ],
            'employmentType' => $empTypes ?: null,
            'jobLocation'    => [
                '@type'   => 'Place',
                'name'    => $loc_name ?: $org_name,
                'address' => self::array_remove_nulls([
                    '@type'           => 'PostalAddress',
                    'streetAddress'   => $street ?: null,
                    'postalCode'      => $pc ?: null,
                    'addressLocality' => $city ?: null,
                    'addressRegion'   => $region ?: null,
                    'addressCountry'  => $country ?: null,
                ])
            ],
        ];

        if ( $salary_value !== '' && is_numeric($salary_value) ) {
            $job['baseSalary'] = [
                '@type' => 'MonetaryAmount',
                'currency' => $salary_currency,
                'value' => [
                    '@type' => 'QuantitativeValue',
                    'value' => (float) $salary_value,
                    'unitText' => $salary_unit ?: null,
                ]
            ];
        }

        if ( $id = get_post_meta($post_id, 'bds_job_identifier', true) ) {
            $job['identifier'] = [
                '@type' => 'PropertyValue',
                'name'  => $org_name,
                'value' => $id,
            ];
        }
        $direct_apply = get_post_meta($post_id, 'bds_job_direct_apply', true);
        if ( $direct_apply !== '' ) $job['directApply'] = (bool) $direct_apply;

        $loc_type = strtoupper( trim( (string) get_post_meta($post_id, 'bds_job_job_location_type', true) ) ); // ON_SITE|HYBRID|REMOTE
        if ( $loc_type === 'REMOTE' ) $job['jobLocationType'] = 'TELECOMMUTE';

        $regions_csv = (string) get_post_meta($post_id, 'bds_job_applicant_location', true);
        $regions = array_values(array_filter(array_map('trim', explode(',', $regions_csv))));
        if ( $regions ) {
            $job['applicantLocationRequirements'] = array_map(function($r){
                return ['@type'=>'AdministrativeArea','name'=>$r];
            }, $regions);
        }

        return self::array_remove_nulls($job);
    }

    /** Event */
    protected static function build_event_node(string $org_name): ?array {
        $post_id = get_the_ID();

        $name    = get_post_meta($post_id, 'bds_event_name', true ) ?: get_the_title($post_id);
        $desc    = wp_strip_all_tags( get_post_meta($post_id, 'bds_event_description', true ) ?: get_the_excerpt($post_id) );

        $start_raw = get_post_meta($post_id, 'bds_event_start', true );
        $end_raw   = get_post_meta($post_id, 'bds_event_end', true );
        $door_raw  = get_post_meta($post_id, 'bds_event_door_time', true );
        $start = self::to_iso8601($start_raw);
        $end   = self::to_iso8601($end_raw);
        $door  = self::to_iso8601($door_raw);

        $status  = get_post_meta($post_id, 'bds_event_status', true ) ?: 'https://schema.org/EventScheduled';
        $mode    = get_post_meta($post_id, 'bds_event_attendance_mode', true ) ?: 'https://schema.org/OfflineEventAttendanceMode';
        $image   = get_the_post_thumbnail_url($post_id, 'full') ?: null;

        $loc_name = get_post_meta($post_id, 'bds_event_location_name', true );
        $street   = get_post_meta($post_id, 'bds_event_street', true );
        $pc       = get_post_meta($post_id, 'bds_event_pc', true );
        $city     = get_post_meta($post_id, 'bds_event_city', true );
        $region   = get_post_meta($post_id, 'bds_event_region', true );
        $country  = get_post_meta($post_id, 'bds_event_country', true ) ?: 'DE';

        $price    = get_post_meta($post_id, 'bds_event_price', true );
        $currency = get_post_meta($post_id, 'bds_event_currency', true ) ?: 'EUR';
        $ticket   = get_post_meta($post_id, 'bds_event_url', true ) ?: get_permalink($post_id);

        $event = [
            '@context'         => 'https://schema.org',
            '@type'            => 'Event',
            'name'             => $name,
            'description'      => $desc,
            'mainEntityOfPage' => get_permalink($post_id),
            'startDate'        => $start ?: null,
            'endDate'          => $end ?: null,
            'doorTime'         => $door ?: null,
            'eventStatus'      => $status,
            'eventAttendanceMode' => $mode,
            'image'            => $image,
            'organizer'        => [
                '@type' => 'Organization',
                'name'  => $org_name,
                'url'   => home_url('/'),
            ],
        ];

        if ( $mode !== 'https://schema.org/OnlineEventAttendanceMode' ) {
            $event['location'] = [
                '@type'  => 'Place',
                'name'   => $loc_name ?: $org_name,
                'address'=> self::array_remove_nulls([
                    '@type'           => 'PostalAddress',
                    'streetAddress'   => $street ?: null,
                    'postalCode'      => $pc ?: null,
                    'addressLocality' => $city ?: null,
                    'addressRegion'   => $region ?: null,
                    'addressCountry'  => $country ?: null,
                ])
            ];
        } else {
            $event['location'] = [
                '@type' => 'VirtualLocation',
                'url'   => get_post_meta($post_id, 'bds_event_stream_url', true ) ?: get_permalink($post_id),
            ];
        }

        $is_free = get_post_meta($post_id, 'bds_event_is_free', true);
        if ( $is_free !== '' ) $event['isAccessibleForFree'] = (bool) $is_free;

        $cap_max  = (int) get_post_meta($post_id, 'bds_event_capacity_max', true);
        $cap_left = (int) get_post_meta($post_id, 'bds_event_capacity_left', true);
        if ( $cap_max > 0 )  $event['maximumAttendeeCapacity']   = $cap_max;
        if ( $cap_left > 0 ) $event['remainingAttendeeCapacity'] = $cap_left;

        if ( $price !== '' && is_numeric($price) ) {
            $event['offers'] = [
                '@type' => 'Offer',
                'url'   => $ticket,
                'price' => (float) $price,
                'priceCurrency' => $currency,
                'availability'  => 'https://schema.org/InStock',
            ];
        }

        return self::array_remove_nulls($event);
    }

    /** LocalBusiness (aus Einstellungen) */
    protected static function build_localbusiness_node(string $org_fallback, ?string $logo_url): ?array {
        $type   = get_option(self::OPT_LB_TYPE, 'LocalBusiness') ?: 'LocalBusiness';
        $name   = get_option(self::OPT_LB_NAME, '') ?: $org_fallback;
        $street = get_option(self::OPT_LB_STREET, '');
        $pc     = get_option(self::OPT_LB_PC, '');
        $city   = get_option(self::OPT_LB_CITY, '');
        $region = get_option(self::OPT_LB_REGION, '');
        $country= get_option(self::OPT_LB_COUNTRY, 'DE');
        $phone  = get_option(self::OPT_LB_PHONE, '');
        $email  = get_option(self::OPT_LB_EMAIL, '');
        $url    = get_option(self::OPT_LB_URL, '') ?: home_url('/');
        $lat    = get_option(self::OPT_LB_GEO_LAT, '');
        $lng    = get_option(self::OPT_LB_GEO_LNG, '');
        $priceR = get_option(self::OPT_LB_PRICERANGE, '');
        $area   = get_option(self::OPT_LB_AREA_SERVED, '');
        $oh     = self::opening_hours_get_option();

        $node = [
            '@context'   => 'https://schema.org',
            '@type'      => $type,
            'name'       => $name,
            'url'        => $url,
            'image'      => $logo_url ?: null,
            'telephone'  => $phone ?: null,
            'email'      => $email ?: null,
            'priceRange' => $priceR ?: null,
            'areaServed' => $area ?: null,
            'address'  => self::array_remove_nulls([
                '@type'           => 'PostalAddress',
                'streetAddress'   => $street ?: null,
                'postalCode'      => $pc ?: null,
                'addressLocality' => $city ?: null,
                'addressRegion'   => $region ?: null,
                'addressCountry'  => $country ?: null,
            ]),
        ];

        if ( $lat !== '' && $lng !== '' && is_numeric($lat) && is_numeric($lng) ) {
            $node['geo'] = [
                '@type' => 'GeoCoordinates',
                'latitude'  => (float) $lat,
                'longitude' => (float) $lng,
            ];
        }

        $spec = self::opening_hours_to_spec($oh);
        if ( $spec ) $node['openingHoursSpecification'] = $spec;

        return self::array_remove_nulls($node);
    }

    /* ------------- Öffnungszeiten-Helper ------------- */

    protected static function weekday_labels(): array {
        return [
            'Mo' => __('Montag','berendsohn-digitalservice'),
            'Di' => __('Dienstag','berendsohn-digitalservice'),
            'Mi' => __('Mittwoch','berendsohn-digitalservice'),
            'Do' => __('Donnerstag','berendsohn-digitalservice'),
            'Fr' => __('Freitag','berendsohn-digitalservice'),
            'Sa' => __('Samstag','berendsohn-digitalservice'),
            'So' => __('Sonntag','berendsohn-digitalservice'),
        ];
    }

    protected static function opening_hours_get_option(): array {
        $raw = get_option(self::OPT_LB_OPENING,'');
        if (!$raw) return [];
        $arr = json_decode($raw, true);
        return is_array($arr) ? $arr : [];
    }

    protected static function opening_hours_to_spec(array $oh): array {
        if (!$oh) return [];
        $map = ['Mo'=>'Monday','Di'=>'Tuesday','Mi'=>'Wednesday','Do'=>'Thursday','Fr'=>'Friday','Sa'=>'Saturday','So'=>'Sunday'];
        $out = [];
        foreach ($oh as $dayKey => $ranges) {
            if (empty($ranges) || empty($map[$dayKey])) continue;
            foreach ($ranges as $r) {
                $opens  = $r['opens']  ?? '';
                $closes = $r['closes'] ?? '';
                if (!$opens || !$closes) continue;
                $out[] = [
                    '@type' => 'OpeningHoursSpecification',
                    'dayOfWeek' => 'https://schema.org/' . $map[$dayKey],
                    'opens'  => $opens,
                    'closes' => $closes,
                ];
            }
        }
        return $out;
    }

    /* ------------- JSON-LD Helper ------------- */
    protected static function jsonld(array $data): string {
        $clean = self::array_remove_nulls($data);
        return '<script type="application/ld+json">' . wp_json_encode($clean, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
}
