<?php
namespace BDS;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Aktiviert die Standard-Taxonomien (z. B. Schlagwörter) für Seiten.
 */
class Page_Taxonomies {
    public static function init() {
        // Tags für Seiten aktivieren
        add_action('init', function() {
            register_taxonomy_for_object_type('post_tag', 'page');
            // Falls du auch Kategorien für Seiten willst, die nächste Zeile aktivieren:
            // register_taxonomy_for_object_type('category', 'page');
        }, 11);

        // Spalten & Quick-Edit im Seiten-Listing aktivieren (optional nice-to-have)
        add_filter('manage_page_posts_columns', [__CLASS__, 'add_tags_column']);
        add_action('manage_page_posts_custom_column', [__CLASS__, 'render_tags_column'], 10, 2);
    }

    public static function add_tags_column($columns) {
        // „Schlagwörter“-Spalte nach dem Titel einfügen (nur wenn noch nicht vorhanden)
        if (!isset($columns['tags'])) {
            $new = [];
            foreach ($columns as $key => $label) {
                $new[$key] = $label;
                if ($key === 'title') {
                    $new['tags'] = __('Schlagwörter');
                }
            }
            return $new;
        }
        return $columns;
    }

    public static function render_tags_column($column, $post_id) {
        if ($column === 'tags') {
            $terms = get_the_terms($post_id, 'post_tag');
            if (!empty($terms) && !is_wp_error($terms)) {
                $names = wp_list_pluck($terms, 'name');
                echo esc_html(implode(', ', $names));
            } else {
                echo '—';
            }
        }
    }
}
