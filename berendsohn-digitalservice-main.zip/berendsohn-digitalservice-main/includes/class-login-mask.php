<?php
namespace BDS;

if ( ! defined( 'ABSPATH' ) ) exit;

class Login_Mask {

    // Public login endpoint slug (no secret key)
    const SLUG = 'mellon';

    public static function init() {
        add_action( 'init', [ __CLASS__, 'add_rewrite' ] );
        add_action( 'template_redirect', [ __CLASS__, 'maybe_route_login' ] );
        add_filter( 'login_url', [ __CLASS__, 'filter_login_url' ], 10, 3 );
        add_action( 'login_enqueue_scripts', [ __CLASS__, 'login_styles' ] );
    }

    /**
     * Register /mellon/ as virtual login endpoint
     */
    public static function add_rewrite() {
        add_rewrite_rule( '^' . self::SLUG . '/?$', 'index.php?bds_login=1', 'top' );
        add_rewrite_tag( '%bds_login%', '1' );
    }

    /**
     * Make /mellon/ the only visible login URL, block wp-login.php and protect wp-admin
     */
    public static function maybe_route_login() {
        $is_mellon = get_query_var( 'bds_login' );

        // 1) Visiting /mellon/ should show the normal WP login form
        if ( $is_mellon ) {
            require_once ABSPATH . 'wp-login.php'; // render the core login form
            exit;
        }

        // 2) Block direct access to wp-login.php and send to /mellon/
        if ( self::is_wp_login_request() ) {
            wp_safe_redirect( home_url( '/' . self::SLUG . '/' ) );
            exit;
        }

        // 3) Protect wp-admin for logged-out users -> send to /mellon/ (preserve desired redirect)
        if ( self::is_wp_admin_request() && ! is_user_logged_in() ) {
            $url = home_url( '/' . self::SLUG . '/' );
            $url = add_query_arg( 'redirect_to', rawurlencode( admin_url() ), $url );
            wp_safe_redirect( $url );
            exit;
        }
    }

    /**
     * Make all generated login links point to /mellon/
     */
    public static function filter_login_url( $login_url, $redirect, $force_reauth ) {
        $url = home_url( '/' . self::SLUG . '/' );
        if ( $redirect ) {
            $url = add_query_arg( 'redirect_to', rawurlencode( $redirect ), $url );
        }
        return $url;
    }

    private static function is_wp_login_request() {
        $pagenow = $GLOBALS['pagenow'] ?? '';
        if ( 'wp-login.php' === $pagenow ) return true;
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        return ( strpos( $uri, 'wp-login.php' ) !== false );
    }

    private static function is_wp_admin_request() {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        return ( strpos( $uri, 'wp-admin' ) !== false );
    }

    public static function login_styles() {
        wp_enqueue_style( 'bds-login', BDS_URL . 'assets/css/login.css', [], BDS_VERSION );
    }
}