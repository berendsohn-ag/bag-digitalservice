<?php
namespace BDS;

if ( ! defined( 'ABSPATH' ) ) exit;

class Shortcodes {

    public static function init() {
        $map = self::shortcode_map();

        foreach ( $map as $shortcode => $file ) {
            add_shortcode( $shortcode, function( $atts = [] ) use ( $file ) {
                return Helpers::read_text( $file );
            } );
        }

        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_public' ] );
    }

    public static function enqueue_public() {
        wp_enqueue_style( 'bds-public', BDS_URL . 'assets/css/public.css', [], BDS_VERSION );
    }

    private static function shortcode_map() {
    return [
        // Impressum
        'impressum'                                              => 'impressum.txt',
        'impressum-englisch'                                     => 'impressum-englisch.txt',

        // Datenschutz
        'datenschutz'                                            => 'datenschutz.txt',
        'datenschutz-youtube'                                    => 'datenschutz-youtube.txt',
        'datenschutz-googlemap-youtube'                          => 'datenschutz-googlemap-youtube.txt',
        'datenschutz-googlemap'                                  => 'datenschutz-googlemap.txt',
        'datenschutz-googlemap-bewerbung'                        => 'datenschutz-googlemap-bewerbung.txt',
        'datenschutz-googlemap-googletagmanager'                 => 'datenschutz-googlemap-googletagmanager.txt',
        'datenschutz-ohne-formular-googlemap'                    => 'datenschutz-ohne-formular-googlemap.txt',
        'datenschutz-ohne-formular-wpstatistics'                 => 'datenschutz-ohne-formular-wpstatistics.txt',
        'datenschutz-ohne-formular'                              => 'datenschutz-ohne-formular.txt',
        'datenschutz-wpstatistics-googlemap-youtube'             => 'datenschutz-wpstatistics-googlemap-youtube.txt',
        'datenschutz-wpstatistics-googlemap'                     => 'datenschutz-wpstatistics-googlemap.txt',
        'datenschutz-googlemap-englisch'                         => 'datenschutz-googlemap-englisch.txt',
        'datenschutz-wpstatistics-googlemap-englisch'            => 'datenschutz-wpstatistics-googlemap-englisch.txt',
        'datenschutz-wpstatistics-youtube'                       => 'datenschutz-wpstatistics-youtube.txt',
        'datenschutz-wpstatistics'                               => 'datenschutz-wpstatistics.txt',

        // Datenschutz Borlabs / Google / Ads / Analytics
        'datenschutz-googlemap-borlabs'                          => 'datenschutz-googlemap-borlabs.txt',
        'datenschutz-borlabs-googletagmanager'                   => 'datenschutz-borlabs-googletagmanager.txt',
        'datenschutz-googlemap-borlabs-googletagmanager-googleads-googleanalytics' 
                                                                  => 'datenschutz-googlemap-borlabs-googletagmanager-googleads-googleanalytics.txt',
        'datenschutz-borlabs-googletagmanager-googleanalytics-kunde' 
                                                                  => 'datenschutz-borlabs-googletagmanager-googleanalytics-kunde.txt',
        'datenschutz-borlabs-googletagmanager-ohne-formular'     => 'datenschutz-borlabs-googletagmanager-ohne-formular.txt',
        'datenschutz-borlabs-googletagmanager-ohne-formular-englisch' 
                                                                  => 'datenschutz-borlabs-googletagmanager-ohne-formular-englisch.txt',
        'datenschutz-googlemap-borlabs-googletagmanager-googleads' 
                                                                  => 'datenschutz-googlemap-borlabs-googletagmanager-googleads.txt',
        'datenschutz-borlabs-googletagmanager-googleads'         => 'datenschutz-borlabs-googletagmanager-googleads.txt',
        'datenschutz-googlemap-borlabs-googletagmanager-googleads_wpstatistics' 
                                                                  => 'datenschutz-googlemap-borlabs-googletagmanager-googleads-wpstatistics.txt',
        'datenschutz-borlabs-googletagmanager-googleads-wpstatistics' 
                                                                  => 'datenschutz-borlabs-googletagmanager-googleads-wpstatistics.txt',
        'datenschutz-googlemap-borlabs-googleads'                => 'datenschutz-googlemap-borlabs-googleads.txt',
        'datenschutz-googlemap-borlabs-googletagmanager'         => 'datenschutz-googlemap-borlabs-googletagmanager.txt',
        'datenschutz-googlemap-facebook-borlabs'                 => 'datenschutz-googlemap-facebook-borlabs.txt',

        // Messenger & Chat
        'datenschutz-whatsapp'                                   => 'datenschutz-whatsapp.txt',
        'datenschutz-chatbot'                                    => 'datenschutz-chatbot.txt',
        'datenschutz-chatbot-googlemap'                          => 'datenschutz-chatbot-googlemap.txt',

        // Sonstiges
        'datenschutz-borlabs-planer-niels-loeser'                => 'datenschutz-borlabs-planer-niels-loeser.txt',
        'datenschutz-googlemap-umzugsrechner'                    => 'datenschutz-googlemap-umzugsrechner.txt',
        'datenschutz-groeger'                                    => 'datenschutz-groeger.txt',
    ];
}
}