jQuery(function($){
  const frame = wp.media({ title: 'Select Logo', button: { text: 'Use this logo' }, multiple: false });
  $('#bds-schema-logo-select').on('click', function(e){
    e.preventDefault();
    frame.off('select').on('select', function(){
      const att = frame.state().get('selection').first().toJSON();
      $('#bds-schema-logo-id').val(att.id);
      $('#bds-schema-logo-preview').attr('src', att.sizes?.medium?.url || att.url).show();
      $('#bds-schema-logo-clear').prop('disabled', false);
    }).open();
  });
  $('#bds-schema-logo-clear').on('click', function(e){
    e.preventDefault();
    $('#bds-schema-logo-id').val('0');
    $('#bds-schema-logo-preview').hide().attr('src','');
    $(this).prop('disabled', true);
  });
});
